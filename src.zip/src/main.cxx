
/* 
 * DFT (Download File Tool)
 * author   scutjaon
 * date     2017/10/27
 */

#include <iostream>
#include <string>
#include <unistd.h>
#include <pthread.h>

#include <curl/curl.h>

using namespace std;

struct tNode
{
    FILE *fp;
    long startPos;
    long endPos;
    void *curl;
    pthread_t tid;
};
int threadCnt = 0;  
static pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;  
  
static size_t writeFunc(void *ptr, size_t size, size_t nmemb, void *userdata)  
{  
    tNode *node = (tNode *) userdata;  
    size_t written = 0;  
    pthread_mutex_lock (&g_mutex);  
    if (node->startPos + size * nmemb <= node->endPos)  
    {  
        fseek (node->fp, node->startPos, SEEK_SET);  
        written = fwrite (ptr, size, nmemb, node->fp);  
        node->startPos += size * nmemb;  
    }  
    else  
    {  
        fseek (node->fp, node->startPos, SEEK_SET);  
        written = fwrite (ptr, 1, node->endPos - node->startPos + 1, node->fp);  
        node->startPos = node->endPos;  
    }  
    pthread_mutex_unlock (&g_mutex);  
    return written;  
}  
  
int progressFunc (void *ptr, double totalToDownload, double nowDownloaded, double totalToUpLoad, double nowUpLoaded)  
{  
    int percent = 0;  
    if (totalToDownload > 0)  
    {  
        percent = (int) (nowDownloaded / totalToDownload * 100);  
    }  
  
    if(percent % 20 == 0)  
        printf ("%0d%%\n", percent);
    return 0;  
}  
  
/************************************************************************/  
/* get the remote file size                                             */  
/************************************************************************/  
long getDownloadFileLenth (const char *url)  
{  
    double downloadFileLenth = 0;  
    CURL *handle = curl_easy_init ();  
    curl_easy_setopt (handle, CURLOPT_URL, url);  
    curl_easy_setopt (handle, CURLOPT_HEADER, 1);
    curl_easy_setopt (handle, CURLOPT_NOBODY, 1);
    if (curl_easy_perform (handle) == CURLE_OK)  
    {  
        curl_easy_getinfo (handle, CURLINFO_CONTENT_LENGTH_DOWNLOAD, &downloadFileLenth);  
    }  
    else  
    {  
        downloadFileLenth = -1;  
    }  
    return downloadFileLenth;  
}  
  
void *workThread (void *pData)  
{  
    tNode *pNode = (tNode *) pData;  
  
    int res = curl_easy_perform (pNode->curl);  
  
    if (res != 0)  
    {  
  
    }  
  
    curl_easy_cleanup (pNode->curl);  
  
    pthread_mutex_lock (&g_mutex);  
    threadCnt--;  
    printf ("thred %ld exit\n", pNode->tid);  
    pthread_mutex_unlock (&g_mutex);  
    delete pNode;  
    pthread_exit (0);  
  
    return NULL;  
}  
  
bool downLoad (int threadNum, string Url, string Path, string fileName)  
{  
    long fileLength = getDownloadFileLenth (Url.c_str ());  
  
    if (fileLength <= 0)  
    {  
        printf ("get the file length error...");  
        return false;  
    }  
  
    // Create a file to save package.  
    const string outFileName = Path + fileName;  
    FILE *fp = fopen (outFileName.c_str (), "wb");  
    if (!fp)  
    {  
        return false;  
    }  
  
    long partSize = fileLength / threadNum;  
  
    for (int i = 0; i <= threadNum; i++)  
    {  
        tNode *pNode = new tNode ();  
  
        if (i < threadNum)  
        {  
            pNode->startPos = i * partSize;  
            pNode->endPos = (i + 1) * partSize - 1;  
        }  
        else  
        {  
            if (fileLength % threadNum != 0)  
            {  
                pNode->startPos = i * partSize;  
                pNode->endPos = fileLength - 1;  
            }  
            else  
                break;  
        }  
  
        CURL *curl = curl_easy_init ();  
  
        pNode->curl = curl;  
        pNode->fp = fp;  
  
        char range[64] = { 0 };  
        snprintf (range, sizeof (range), "%ld-%ld", pNode->startPos, pNode->endPos);  
  
        // Download pacakge  
        curl_easy_setopt (curl, CURLOPT_URL, Url.c_str ());  
        curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, writeFunc);  
        curl_easy_setopt (curl, CURLOPT_WRITEDATA, (void *) pNode);  
        curl_easy_setopt (curl, CURLOPT_NOPROGRESS, 0L);  
        curl_easy_setopt (curl, CURLOPT_PROGRESSFUNCTION, progressFunc);  
        curl_easy_setopt (curl, CURLOPT_NOSIGNAL, 1L);  
        curl_easy_setopt (curl, CURLOPT_LOW_SPEED_LIMIT, 1L);  
        curl_easy_setopt (curl, CURLOPT_LOW_SPEED_TIME, 5L);  
        curl_easy_setopt (curl, CURLOPT_RANGE, range);  
  
        pthread_mutex_lock (&g_mutex);  
        threadCnt++;  
        pthread_mutex_unlock (&g_mutex);  
        int rc = pthread_create (&pNode->tid, NULL, workThread, pNode);  
    }  
  
    while (threadCnt > 0)  
    {  
        usleep (1000000L);  
    }  
  
    fclose (fp);  
  
    printf ("download succed......\n");  
    return true;  
}

int main(int argc, char **argv)
{
    /*
     *  download files using multi-process with http
     */
    /*
    #include <iostream>
    #include <string>
    #include <unistd.h>
    #include <pthread.h>

    #include "http_client.hxx"
    #include "common.hxx"

    int main(int argc, char **argv)
    {
        bool ret = false;

        // init curl environment
        curl_global_init(CURL_GLOBAL_DEFAULT);

        // http download file
        HttpClient httpClient();
        ret = httpClient.download_file(remote_url, local_path);
        if(!ret){
            std::cout << "error download file!!  url : " << url << std::endl;
        }else{
            std::cout << "ok download file!! " << std::endl;
        }

        // waiting for done
        cin.get();

        // clear the environment
        curl_global_cleanup();

        return 0;
    }
    */
    downLoad(10, "http://ardownload.adobe.com/pub/adobe/reader/win/11.x/11.0.01/en_US/AdbeRdr11001_en_US.exe", "./", "AdbeRdr11001_en_US.exe");

    cin.get();
    return 0;  
}   

