//
// Created by 10171618 on 2017/10/30.
//

#include <iostream>
#include <pthread.h>
#include "down_file.hxx"

size_t DownFile::process(void *buffer, size_t size, size_t nmemb, void *stream)
{
    tNode *node = (tNode *) stream;
    size_t written = 0;
    pthread_mutex_lock (&g_mutex);
    if (node->startPos + size * nmemb <= node->endPos)
    {
        fseek (node->fp, node->startPos, SEEK_SET);
        written = fwrite (buffer, size, nmemb, node->fp);
        node->startPos += size * nmemb;
    }
    else
    {
        fseek (node->fp, node->startPos, SEEK_SET);
        written = fwrite (buffer, 1, node->endPos - node->startPos + 1, node->fp);
        node->startPos = node->endPos;
    }
    pthread_mutex_unlock (&g_mutex);
    return written;
}