//
// Created by jason on 2017/10/30.
//

#include <iostream>
#include <string.h>
#include "down_file.h"

// mutex for fwrite correctly
pthread_mutex_t g_mutex = PTHREAD_MUTEX_INITIALIZER;

DownFile::DownFile(const int thrd_num, const std::string url, const std::string path):
        _thread_num(thrd_num),
        _url(url),
        _path(path)
{
}

DownFile::~DownFile()
{
}

// thread excute function
void* DownFile::run (void *arg)
{
    tHttpFile *pData = (tHttpFile *) arg;
    // block, until done
    curl_easy_perform (pData->curl);
    // clean env
    curl_easy_cleanup (pData->curl);
    std::cout << "exit thread ok " << pthread_self() << std::endl;
    delete pData;
    pthread_exit((void *)0);
}

// callback function, get data from url
size_t DownFile::my_fwrite(void *buffer, size_t size, size_t nmemb, void *stream)
{
    tHttpFile *data = (tHttpFile *) stream;
    size_t nw = 0;

    // get lock
    pthread_mutex_lock (&g_mutex);
    fseek (data->fp, data->startPos, SEEK_SET);
    // you can write size * nmemb data
    if (data->startPos + (long)(size * nmemb) <= data->endPos){
        nw = fwrite(buffer, size, nmemb, data->fp);
        data->startPos += size * nmemb;
    }else{
        nw = fwrite (buffer, 1, data->endPos - data->startPos + 1, data->fp);
        data->startPos = data->endPos;
    }
    pthread_mutex_unlock (&g_mutex);

    return nw;
}

// down file entry
bool DownFile::start()
{
    // get file size
    std::string filename;
    std::string local_path;
    std::string range;
    long thread_down_size;
    int err;
    void *tret;
    long file_size = httpClient.get_file_size(_url);
    if (file_size <= 0){
        std::cout << "get the file size error" << std::endl;
        return false;
    }
    // get filename
    // open file, save the fp
    filename = strrchr(_url.c_str(), '/') + 1;
    if('/' != _path[_path.length()-1]) _path += '/';
    local_path = _path + filename;
    _fp = fopen (local_path.c_str (), "wb");
    if (!_fp) return false;

    // start thread
    thread_down_size = file_size / _thread_num;
    for (int i = 0; i <= _thread_num; i++){
        tHttpFile *pData = new tHttpFile;
        if (i < _thread_num){
            pData->startPos = i * thread_down_size;
            pData->endPos = (i + 1) * thread_down_size - 1;
        }else{
            if (0 != file_size % _thread_num){
                pData->startPos = i * thread_down_size;
                pData->endPos = file_size - 1;
            }else break;
        }
        // init thread evn
        CURL *curl = curl_easy_init ();
        pData->curl = curl;
        pData->fp = _fp;

        // range, download file part "0-100"
        // set opt
        range = std::to_string(pData->startPos)+ "-" +std::to_string(pData->endPos);
        curl_easy_setopt (curl, CURLOPT_URL, _url.c_str());
        curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, my_fwrite);
        curl_easy_setopt (curl, CURLOPT_WRITEDATA, (void *) pData);
        curl_easy_setopt (curl, CURLOPT_NOSIGNAL, 1L);
        //curl_easy_setopt (curl, CURLOPT_LOW_SPEED_LIMIT, 1L); // speed
        //curl_easy_setopt (curl, CURLOPT_LOW_SPEED_TIME, 5L);
        curl_easy_setopt (curl, CURLOPT_RANGE, range.c_str()); // set range for every thread

        // run
        int rc = pthread_create (&pData->tid, NULL, run, pData);
        if( 0 ==  rc) {
            _tid.push_back(pData->tid);
        }
    }

    // wait for every thread
    int vsize = _tid.size();
    for (int i = 0; i < vsize; i++){
        err = pthread_join(_tid[i], &tret);
        if(0 != err){
            std::cout<< "join thread err " << _tid[i] <<std::endl;
        }else{
            std::cout<< "join thread ok " << _tid[i] <<std::endl;
        }
    }

    // close fp
    fclose (_fp);
    return true;
}

