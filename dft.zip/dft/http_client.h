//
// Created by jason on 2017/10/30.
//

#ifndef DFT_HTTP_CLIENT_H
#define DFT_HTTP_CLIENT_H

#include <iostream>
#include <curl/curl.h>

class HttpClient{
public:
    HttpClient();
    ~HttpClient();
    long get_file_size (const std::string &url);
private:

};
#endif //DFT_HTTP_CLIENT_H
