//
// Created by 10171618 on 2017/10/30.
//

#ifndef HTTP_FILE_H
#define HTTP_FILE_H

#include <iostream>

#include "common.hxx"
#include "down_file.hxx"
#include <curl/curl.h>

class HttpClient{
public:
    HttpClient();
    ~HttpClient();
    bool download_file(std::string url, std::string path);

private:
    DownFile    downFile;
};
#endif //HTTP_FILE_H
