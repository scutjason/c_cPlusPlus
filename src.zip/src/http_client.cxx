//
// Created by 10171618 on 2017/10/30.
//
#include <string.h>
#include "http_file.hxx"
#include "common.hxx"

HttpClient::HttpClient()
{
}

HttpClient::~HttpClient()
{
}

unsigned long HttpClient:: get_file_size (const std::string &url)
{
    CURL *curl;
    CURLcode res;
    double filesize = 0.0;

    curl = curl_easy_init ();
    if(curl) {

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        /* No download if the file */
        curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
        /* Get header output */
        curl_easy_setopt(curl, CURLOPT_HEADER, 1L);

        res = curl_easy_perform(curl);
        if(CURLE_OK == res){
            res = curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD,
                                    &filesize);
            if((CURLE_OK == res) && (filesize>0.0))
                std::cout << "get filesize : " << filesize << std::endl;
        } else {
            /* we failed */
            std::cout << "curl told us " << res << std::endl;
            filesize = -1.0;
        }
        curl_easy_cleanup(handle);
    }
    return filesize;
}

bool HttpClient::download_file(std::string url, std::string path)
{

    unsigned long file_size = get_file_size (url);
    if (file_size <= 0){
        std::cout << "get the file size error" << std::endl;
        return false;
    }

    // get filename
    const std::string filename = strrchr(url.c_str(), '/') + 1;
    if('/' != path[path.length()-1]){
        path += '/';
    }
    const std::string local_path = path + filename;

    // open file, save the fp
    FILE *fp = fopen (local_path.c_str (), "wb");
    if (!fp){
        return false;
    }

    long thread_down_size = file_size / thread_num;
    for (int i = 0; i <= threadNum; i++)
    {
        tNode *pNode = new tNode ();

        if (i < threadNum)
        {
            pNode->startPos = i * partSize;
            pNode->endPos = (i + 1) * partSize - 1;
        }
        else
        {
            if (fileLength % threadNum != 0)
            {
                pNode->startPos = i * partSize;
                pNode->endPos = fileLength - 1;
            }
            else
                break;
        }

        CURL *curl = curl_easy_init ();
        pNode->curl = curl;
        pNode->fp = fp;
        char range[64] = { 0 };
        snprintf (range, sizeof (range), "%ld-%ld", pNode->startPos, pNode->endPos);

        // Download pacakge
        curl_easy_setopt (curl, CURLOPT_URL, Url.c_str ());
        curl_easy_setopt (curl, CURLOPT_WRITEFUNCTION, writeFunc);
        curl_easy_setopt (curl, CURLOPT_WRITEDATA, (void *) pNode);
        curl_easy_setopt (curl, CURLOPT_NOPROGRESS, 0L);
        curl_easy_setopt (curl, CURLOPT_PROGRESSFUNCTION, progressFunc);
        curl_easy_setopt (curl, CURLOPT_NOSIGNAL, 1L);
        curl_easy_setopt (curl, CURLOPT_LOW_SPEED_LIMIT, 1L);
        curl_easy_setopt (curl, CURLOPT_LOW_SPEED_TIME, 5L);
        curl_easy_setopt (curl, CURLOPT_RANGE, range);

        pthread_mutex_lock (&g_mutex);
        threadCnt++;
        pthread_mutex_unlock (&g_mutex);
        int rc = pthread_create (&pNode->tid, NULL, workThread, pNode);
    }

    while (threadCnt > 0)
    {
        usleep (1000000L);
    }

    fclose (fp);

    printf ("download succed......\n");
    return true;
}