//
// Created by jason on 2017/10/30.
//

#include "http_client.h"

HttpClient::HttpClient()
{
}

HttpClient::~HttpClient()
{
}

long HttpClient:: get_file_size (const std::string &url)
{
    CURL *curl;
    CURLcode res;
    double filesize = 0;

    curl = curl_easy_init ();
    if(curl) {

        curl_easy_setopt(curl, CURLOPT_URL, url.c_str());
        /* No download if the file */
        curl_easy_setopt(curl, CURLOPT_NOBODY, 1L);
        /* Get header output */
        curl_easy_setopt(curl, CURLOPT_HEADER, 1L);

        res = curl_easy_perform(curl);
        if(CURLE_OK == res){
            res = curl_easy_getinfo(curl, CURLINFO_CONTENT_LENGTH_DOWNLOAD,
                                    &filesize);
            if((CURLE_OK == res) && (filesize>0.0))
                std::cout << "get filesize : " << (long)filesize << std::endl;
        } else {
            /* we failed */
            std::cout << "curl told us " << res << std::endl;
            filesize = -1;
        }
        curl_easy_cleanup(curl);
    }
    return filesize;
}

