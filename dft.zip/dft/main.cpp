/*
 *  DFT; Download File Tool
 *
 *  author  jason
 *  date    2017/10/30
==============================================================================*/

#include <iostream>
#include <string>
#include <unistd.h>
#include <stdlib.h>
#include <time.h>

#include <curl/curl.h>
#include "down_file.h"

// main
int main(int argc, char **argv)
{
    bool ret = false;
    const std::string remote_url = "http://yann.lecun.com/exdb/mnist/train-images-idx3-ubyte.gz";
    const std::string local_path = "./";
    const int thread_num = 20;
    const time_t start_time = time(NULL);

    // init global curl environment
    curl_global_init(CURL_GLOBAL_DEFAULT);

    // download file
    DownFile downFile(thread_num, remote_url, local_path);
    ret = downFile.start();
    const time_t end_time = time(NULL);
    if(!ret){
        std::cout << "download file ok , cost " << end_time-start_time << "(s)"<< std::endl;
    }else{
        std::cout << "download file ok , cost " << end_time-start_time << "(s)"<< std::endl;
    }

    // md5sum check file, we get the md5 f68b3c2dcbeaaa9fbdd348bbdeb94873 before download
    system("echo f68b3c2dcbeaaa9fbdd348bbdeb94873 train-images-idx3-ubyte.gz > downfile.md5");
    pid_t status = system("md5sum -c downfile.md5");
    if (0 == status){
        std::cout<< "md5sum check ok" << std::endl;
    }else{
        std::cout<<"md5sum check fail" << std::endl;
    }

    // clear the environment
    curl_global_cleanup();

    return 0;
}