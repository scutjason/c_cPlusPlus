//
// Created by jason on 2017/10/30.
//

#ifndef DFT_DOWN_FILE_H
#define DFT_DOWN_FILE_H

#include <iostream>
#include <cstddef>
#include <vector>
#include "http_client.h"


typedef struct HttpFile {
    pthread_t tid;
    FILE *fp;
    long startPos;
    long endPos;
    void *curl;
} tHttpFile;

class DownFile{
public:
    DownFile(const int thrd_num, const std::string url, const std::string path);
    ~DownFile();
    bool start();
    static size_t my_fwrite(void *buffer, size_t size, size_t nmemb, void *stream);
    static void *run (void *arg);

private:
    int _thread_num;
    FILE *_fp;
    std::string _url;
    std::string _path;
    std::vector<pthread_t> _tid;
    HttpClient httpClient;
};

#endif //DFT_DOWN_FILE_H
