//
// Created by 10171618 on 2017/10/30.
//

#ifndef DOWN_FILE_H
#define DOWN_FILE_H

class DownFile{
public:
    DownFile();
    ~DownFile();
    void *process(void *buffer, size_t size, size_t nmemb, void *stream);
private:

};
#endif //DOWN_FILE_H
