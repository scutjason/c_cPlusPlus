//
// Created by 10171618 on 2017/10/30.
//

#include <iostream>

#ifndef COMMON_H
#define COMMON_H

const int thread_num = 20;
const std::string remote_url = "http://ardownload.adobe.com/pub/adobe/reader/win/11.x/11.0.01/en_US/AdbeRdr11001_en_US.exe";
const std::string local_path = "/tmp";
#endif //COMMON_H
